﻿// ReSharper disable All

using System;
using Krugames.LocalizationSystem.Models;
using Krugames.LocalizationSystem.Models.Dynamic;
using Krugames.LocalizationSystem.Models.Interfaces;
using UnityEngine;

namespace Krugames.LocalizationSystem.Examples {
    internal class MainAPIExample {
        private void Example() {

            // Получить текущий используемый язык
            SystemLanguage currentLanguage = Localization.CurrentLanguage;

            // Получить набор локализации для текущего языка
            ILocale currentLocale = Localization.CurrentLocale;

            // Получить все динамические наборы локализации
            DynamicLocale[] dynamicLocales = Localization.DynamicLocales;

            // Получить перечень всех поддерживаемых языков
            SystemLanguage[] supportedLanguage = Localization.SupportedLanguages;

            // Получить перечень всех проверенных наборов локализации 
            ILocale[] validLocales = Localization.ValidLocales;

            // Получить проверенный базовый набор локализации 
            ILocale baseValidLocale = Localization.BaseValidLocale;

            // Провести инициализацию системы вручную или досрочно
            Localization.Initialize();

            // Получить набор локализации по языку
            ILocale locale = Localization.GetLocale(SystemLanguage.English);

            // Установить текущий язык
            Localization.SetLanguage(SystemLanguage.Russian);

            // Проверить поддерживается ли язык
            bool hasLanguage = Localization.SupportsLanguage(SystemLanguage.Swedish);

            // Добавить новый динамический набор локализации в систему
            DynamicLocale dynamicLocale = new DynamicLocale();
            Localization.AddDynamicLocale(dynamicLocale);

            // Удалить существующий динамический набор локализации
            Localization.RemoveDynamicLocale(dynamicLocale);

            // Отгрузить все неиспользуемые динамические ресурсы
            Localization.UnloadUnusedResources();

            // Получить обобщеенное значение термина
            object gValue = Localization.GetTermValue("term_name");

            // Получить обобщенное значение термина с определенным типом
            object tgValue = Localization.GetTermValue("term_name", typeof(string));

            // Получить значение термина определенного типа
            string value = Localization.GetTermValue<string>("term_name");

            // Получить обобщеенное значение термина для опредленного языка
            object glValue = Localization.GetTermValue("term_name", SystemLanguage.English);

            // Получить обобщенное значение термина с определенным типом, для определенного языка
            object tglValue = Localization.GetTermValue("term_name", typeof(string), SystemLanguage.English);

            // Получить значение термина определенного типа для определенного языка
            string lValue = Localization.GetTermValue<string>("term_name", SystemLanguage.English);

            // Добавить колбек на смену языка
            void Callback() {
                Console.WriteLine("Language was changed");
            };
            Localization.AddLanguageUpdateCallback(Callback);

            //Добавить усложненный колбек на смену языка
            void ComplexCallback(LocaleLibrary library, SystemLanguage oldLang, SystemLanguage newLang) {
                Console.WriteLine($"Language was changed from{oldLang} to {newLang} in {library}");
            };
            Localization.AddLanguageUpdateCallback(ComplexCallback);

            // Удалить существующий колбек на смену языка
            Localization.RemoveLanguageUpdateCallback(Callback);

            // Удалить существующий усложненный колбек на смену языка
            Localization.RemoveLanguageUpdateCallback(ComplexCallback);

        }
    }
}