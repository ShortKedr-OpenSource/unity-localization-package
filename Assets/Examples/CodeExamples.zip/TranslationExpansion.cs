﻿// Resharper Disable all

using Krugames.LocalizationSystem.Translation;
using Krugames.LocalizationSystem.Translation.Attributes;
using UnityEngine;

[assembly: RegisterTranslator(typeof(MyCustomTranslator))]

public class MyCustomTranslator : StringTranslator {
    public override void Translate(string data, SystemLanguage from, SystemLanguage to, TranslationSuccessDelegate successCallback,
        TranslationFailDelegate failCallback) {

        bool success = Random.Range(0, 100) > 50;
        if (success) successCallback?.Invoke("This is translated text", to, from);
        else failCallback?.Invoke(data, from, to);
    }
}