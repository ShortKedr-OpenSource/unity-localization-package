﻿//Resharper Disable all

using UnityEngine;
using Krugames.LocalizationSystem.Editor.UI.ValidationWindow;
using UnityEditor;

using System.Collections.Generic;
using Krugames.LocalizationSystem.Models;
using Krugames.LocalizationSystem.Models.Validation;


public class MyValidator : Validator<Locale> {
    public override ValidationReport<Locale> ValidateWithReport(Locale validationSubject) {
        List<ValidationError> errors = new List<ValidationError>(16);
        errors.Add(new ValidationError("This is error example"));
        errors.Add(new ValidationError("Another error example"));
        
        ValidationReport<Locale> report = new ValidationReport<Locale>(validationSubject, errors.ToArray());
        return report;
    }
}

public class ValidationExpansionExample {

    [MenuItem("Examples/Validation")]
    private static void LaunchReport() {
        Locale locale = (Locale)LocaleLibrary.Instance.BaseLocale;
        
        MyValidator validator = new MyValidator();
        ValidationReport report = validator.ValidateWithReport(locale);
        ValidationReportWindow.ShowReport(report, $"Validation for {locale.name}");
    }
}
