﻿// ReSharper disable All

using System;
using Krugames.LocalizationSystem.Editor.Serialization;
using Krugames.LocalizationSystem.Editor.Serialization.Attributes;
using Krugames.LocalizationSystem.Models.Interfaces;

[assembly: RegisterLocaleSerializer(typeof(FunnySerializer), "Funny File", "funny")]

public class FunnySerializer : LocaleSerializer<string> {
    public override string SerializeSmart(ILocale locale) {
        return $"{locale.Language}\n" +
               $"This is serialized data";
    }

    public override void DeserializeSmart(IModifiableLocale targetLocale, string data) {
        Console.WriteLine("No serialization for Funny Files");
    }
}