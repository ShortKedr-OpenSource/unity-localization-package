﻿// ReSharper disable All

using System;
using Krugames.LocalizationSystem.Models;
using Krugames.LocalizationSystem.Models.Attributes;

[assembly: RegisterLocaleTerm(typeof(PersonTerm), "Person Data")]

public class PersonTerm : LocaleTerm<PersonData> {
    
}

[Serializable]
public class PersonData {
    public string firstName;
    public string secondName;
    public Gender gender;
    public int age;

    public override string ToString() {
        return $"{nameof(PersonData)} ({firstName} {secondName}, {gender}, {age})";
    }
}

public enum Gender {
    Male = 0,
    Female = 1,
}
